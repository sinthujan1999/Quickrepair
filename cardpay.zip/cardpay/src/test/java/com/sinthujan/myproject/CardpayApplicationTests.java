package com.sinthujan.myproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardpayApplicationTests {

	@Test
	void contextLoads() {
	}

}
