package com.sinthujan.myproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.sinthujan.StripeService.StripeService;
import com.sinthujan.stripe.controllers.PaymentController;

@SpringBootApplication
@ComponentScan(basePackageClasses=PaymentController.class)
@ComponentScan(basePackageClasses=StripeService.class)
public class CardpayApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardpayApplication.class, args);
	}

}
