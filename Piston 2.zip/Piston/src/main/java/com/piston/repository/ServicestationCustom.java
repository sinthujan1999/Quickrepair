package com.piston.repository;



public interface ServicestationCustom {
//	public List<Servicestation> getMinWorkId(String[] VehicleTypes);
	public Double getMinWorkId();
	
}
