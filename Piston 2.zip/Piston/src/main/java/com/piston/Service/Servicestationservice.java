package com.piston.Service;

import java.util.ArrayList;
import java.util.Date;
//import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;


//import javax.validation.executable.ValidateOnExecution;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Example;
//import org.springframework.data.domain.ExampleMatcher;
//import org.springframework.data.domain.ExampleMatcher.GenericPropertyMatcher;
//import org.springframework.data.domain.ExampleMatcher.StringMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import com.piston.exception.RecordNotFoundException;

import com.piston.model.Servicestation;
import com.piston.repository.ServicestationCustom;
import com.piston.repository.ServicestationRepository;





@Service
public class Servicestationservice {
	 @Autowired
		private ServicestationCustom servicestationCustom;

	@Autowired
	ServicestationRepository servicestationRepository;

	public ResponseEntity<List<Servicestation>> getAllServicestations() {
		List<Servicestation> servicestations = new ArrayList<Servicestation>();
		servicestationRepository.findAll().forEach(servicestations::add);
	
	    if (servicestations.isEmpty()) {
	      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    }
	    return new ResponseEntity<>(servicestations, HttpStatus.OK);
	}
	
	





	public ResponseEntity<Servicestation> findByVehicleType(String[] vehicleTypes) throws RecordNotFoundException {
		Optional<Servicestation> servicestations = servicestationRepository.findByVehicleTypes(vehicleTypes);
//for (int i = 0; i < vehicleTypes.length; i++) {
//	 System.out.println(vehicleTypes[i]); 
//	
//}
		if (servicestations.isPresent()) {
		
			return new ResponseEntity<>(servicestations.get(), HttpStatus.OK);
		} else {
			throw new RecordNotFoundException("This" + vehicleTypes+"service didn't work");
		}
	}



	
	public ResponseEntity<Servicestation> findByServiceType(String[] serviceType) throws RecordNotFoundException {
		Optional<Servicestation> servicestations = servicestationRepository.findByServiceType(serviceType);
		
		if (servicestations.isPresent()) {
			return new ResponseEntity<>(servicestations.get(), HttpStatus.OK);
		} else {
			throw new RecordNotFoundException("This" + serviceType+"doesn't work in station");
		}
	}





	public ResponseEntity<Servicestation> createServicestation( Servicestation servicestation) {
		

		try {
		
			Servicestation servicestations =servicestationRepository.insert(servicestation);
			servicestations.setDate(new Date());
			return new ResponseEntity<>(servicestations,HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}



	public ResponseEntity<HttpStatus> deleteServicestation(String companyName) throws RecordNotFoundException {
		{
			Optional<Servicestation> servicestation=servicestationRepository.findByCompanyName(companyName);
			if (servicestation.isPresent()) {
				servicestationRepository.delete(servicestation.get());
			    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			} else {
				throw new RecordNotFoundException("Invalid Student Number : " + companyName);
			}
		}
	}







	public ResponseEntity<HttpStatus> deleteServicestationbyId(String id) throws RecordNotFoundException
	{
		Optional<Servicestation> deleteservicestation = servicestationRepository.findById(id);
			if(deleteservicestation.isPresent()) {
				servicestationRepository.delete(deleteservicestation.get());
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}else {
				throw new RecordNotFoundException("Not Deleted by this"+id);
			
			}
			
		}



	public ResponseEntity<HttpStatus> deleteAllServicestation() throws RecordNotFoundException {
	try {
		
		
		List<Servicestation> deleteAllServicestations =servicestationRepository.findAll();
		if (deleteAllServicestations.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		else {
			servicestationRepository.deleteAll(deleteAllServicestations);
			return new ResponseEntity<>(HttpStatus.ACCEPTED);
			
		}
		
	} catch (Exception e) {
		throw new RecordNotFoundException("Not Deleted");
		
	}
	}


	
	
//	public ResponseEntity<List<Quickrepair>> getQuickrepairByFilter( String[] vehicleTypes
//			) {
//		List<Servicestation> workDistance = servicestationCustom.getMinWorkId(vehicleTypes);
//		
//		 try {
//		   	 	List<Servicestation> Servicestations= servicestationRepository.findByBetterCompany(workDistance);
//		   	 
//		   	 	if (Servicestations.isEmpty()) {
//		   	   	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//		   	 	}
//		   	 
//		   	 	return new ResponseEntity<>(Servicestations, HttpStatus.OK);
//		   	 } catch (Exception e) {
//		   	 	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
//		   	 }
//}
	public ResponseEntity<List<Servicestation>> getQuickrepairByFilter(String[] serviceType, String[] vehicleTypes,
			Double latitude, Double longitude, String opentime, String finishtime) {
		Double workDistance = servicestationCustom.getMinWorkId();
		 try {
		   	 	List<Servicestation> Servicestations= servicestationRepository.findByBetterCompany(serviceType,vehicleTypes,latitude,longitude,opentime,finishtime,workDistance);
		   	 
		   	 	if (Servicestations.isEmpty()) {
		   	   	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		   	 	}
		   	 
		   	 	return new ResponseEntity<>(Servicestations, HttpStatus.OK);
		   	 } catch (Exception e) {
		   	 	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		   	 }
}




	public ResponseEntity<Map<String, Object>> getAllServiceStationsInPage(int pageNo, int pageSize, String sortBy) {
		 try {
	   		 Map<String, Object> response = new HashMap<>();
	   	 	Sort sort = Sort.by(sortBy);
	   		 Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
	   	 	Page<Servicestation> page = servicestationRepository.findAll(pageable);
	   	 	response.put("data", page.getContent());
	   	 	response.put("Total no of pages", page.getTotalPages());
	   	 	response.put("Total no of elements", page.getTotalElements());
	   	 	response.put("Current page no", page.getNumber());
	   		 
	   	 	return new ResponseEntity<>(response, HttpStatus.OK);
	   	 } catch (Exception e) {
	   	 	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	   	 }

		
	}







	public ResponseEntity<List<Servicestation>> getServicestationByOpentimeAndFinishtime(String opentime,
			String finishtime) {
		 try {
		   	 	List<Servicestation> servicestations = servicestationRepository.findServicestationsByOpentimeAndFinishtime(opentime, finishtime);
		   	 
		   	 	if (servicestations.isEmpty()) {
		   	   	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		   	 	}
		   	 
		   	 	return new ResponseEntity<>(servicestations, HttpStatus.OK);
		   	 } catch (Exception e) {
		   	 	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		   	 }

	
	}







//	public ResponseEntity<List<Servicestation>> getMin() {
//		Double workDistance = servicestationCustom.getMinWorkId();
//		try {	
//		   	 List<Servicestation> get = servicestationRepository.findByWorkDistance(workDistance);
//
//
//		   	 	if (get.isEmpty()) {
//		   	   	return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//		   	 	}
//		   	 	return new ResponseEntity<>(get, HttpStatus.OK);
//		   	 } catch (Exception e) {
//		   	 	return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//		   	 }
//		
//	}





	public ResponseEntity<Servicestation> updateServicestation(String id, Servicestation servicestation) {
		 Optional<Servicestation> servicestationData = servicestationRepository.findById(id);

	   	 if (servicestationData.isPresent()) {
	   		 Servicestation _servicestation = servicestationData.get();
	   		_servicestation.setAddress(servicestation.getAddress());
	   		_servicestation.setCompanyName(servicestation.getCompanyName());
	   	 	_servicestation.setDescription(servicestation.getDescription());
	   	 	_servicestation.setEmailAddress(servicestation.getEmailAddress());
	   	 	_servicestation.setFinishtime(servicestation.getFinishtime());
	   	 	_servicestation.setLatitude(servicestation.getLatitude());
	   	 	_servicestation.setLongtitude(servicestation.getLongtitude());
	   	 	_servicestation.setOpentime(servicestation.getOpentime());
	   	 _servicestation.setPhoneNumber(servicestation.getPhoneNumber());
	   	 	_servicestation.setWorkDistance(servicestation.getWorkDistance());
	   	 	
	   	 	_servicestation.setVehicleTypes(servicestation.getVehicleTypes());
	   	 	_servicestation.setServiceType(servicestation.getServiceType());
	   	 	
	  
	   	 	return new ResponseEntity<>(servicestationRepository.save(_servicestation), HttpStatus.OK);
	   	 } else {
	   	 	return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	   	 }

	}







	public ResponseEntity<List<Servicestation>> getServicestationByCompanyName(String companyName) {
		 try {
		   	 	List<Servicestation> servicestations = new ArrayList<Servicestation>();
		   	 
		   	 	if (companyName== null) {
		   	 	servicestationRepository.findAll().forEach(servicestations::add);
		   	 	} else {
		   	 	servicestationRepository.findByCompanyNameContaining(companyName).forEach(servicestations::add);
		   	 	}
		   	 
		   	 	if (servicestations.isEmpty()) {
		   	   	      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		   	 	}
		   	 
		   	 	return new ResponseEntity<>(servicestations, HttpStatus.OK);
		   	 } catch (Exception e) {
		   	 	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		   	 }

	}







//	public ResponseEntity<List<Servicestation>> getAllByget(Servicestation servicestation) {
//		try {
//			List<Servicestation> service= new ArrayList<Servicestation>();
//			ExampleMatcher matcher =ExampleMatcher.matchingAny().withIgnoreCase().withMatcher("companyName", GenericPropertyMatcher.of(StringMatcher.ENDING));
//		Example<Servicestation>example=Example.of(servicestation,matcher);
//		servicestationRepository.findAll(example).forEach(service::add);
//	   	 	if (service.isEmpty()) {
//	   	   	   	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//	   	   	 	}
//	   	   	 
//	   	   	 	return new ResponseEntity<>(service, HttpStatus.OK);
//	   	   	 } catch (Exception e) {
//	   	   	 	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
//	   	   	 }
//	   	    }







	public ResponseEntity<List<Servicestation>> getservicestationserviceById(String id) {
		try {
			List<Servicestation> byid = servicestationRepository.findServiceStationsById(id);
			if(byid.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}else {
				return new ResponseEntity<>(byid ,HttpStatus.OK);
			}
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	
}










	
