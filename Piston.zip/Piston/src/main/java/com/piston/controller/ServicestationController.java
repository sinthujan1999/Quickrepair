package com.piston.controller;

import java.util.List;
import java.util.Map;


import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.piston.Service.Servicestationservice;
import com.piston.exception.RecordNotFoundException;
import com.piston.model.Servicestation;



@CrossOrigin(origins = {"http://localhost:3000"})
@RestController
@RequestMapping("/piston/servicestations")
public class ServicestationController {
	private static final Logger logger = LoggerFactory.getLogger(ServicestationController.class);
	@Autowired
	private Servicestationservice servicestationservice;
	
	
	 @GetMapping
	    public ResponseEntity<List<Servicestation>> getAllServicestations() {
	        return servicestationservice.getAllServicestations();
	    }
	 
	 @GetMapping( params = {"opentime","finishtime"} )
	    public ResponseEntity<List<Servicestation>> getEmployeesByFullNameAndFinishtime(@RequestParam String opentime,
	   		 @RequestParam String finishtime) {
	   	 return servicestationservice.getServicestationByOpentimeAndFinishtime(opentime,finishtime);
	    }

		
	 @GetMapping(params = "serviceType")
	    public ResponseEntity<Servicestation> getServicestationByServiceType(@RequestParam String serviceType) throws RecordNotFoundException {
		 String[] serviceTypes = serviceType.split(",");
	        return servicestationservice.findByServiceType(serviceTypes);
	 
	 } 
	  @GetMapping(params = "vehicleTypes")
	public ResponseEntity<Servicestation> getServicestationByVehicleType(@RequestParam String vehicleTypes) throws RecordNotFoundException {
	        	String[] VehicleTypes = vehicleTypes.split(",");
	        	return servicestationservice.findByVehicleType(VehicleTypes);
	        }
	  
	  @GetMapping(params = "companyName")
	  public ResponseEntity<List<Servicestation>> getServicestationByCompanyName(@RequestParam String companyName) {
	      return servicestationservice.getServicestationByCompanyName(companyName);
	  }


	  @DeleteMapping(value = "/{companyName}")
	    public ResponseEntity<HttpStatus> deleteServicestation(@PathVariable String companyName) throws RecordNotFoundException {
	        return servicestationservice.deleteServicestation(companyName);
	    }

	  @DeleteMapping(value = "/{id}")  
	  public ResponseEntity<HttpStatus> deleteServicestationbyId(@PathVariable Long id) throws RecordNotFoundException {
	        return servicestationservice.deleteServicestationbyId(id);
	    }
	  
   @PostMapping
      public ResponseEntity<Servicestation> createServicestation(@Valid  @RequestBody Servicestation servicestation) {
    return servicestationservice.createServicestation(servicestation);
		        }
		        
   @DeleteMapping
   	  public ResponseEntity<HttpStatus> deleteAllServicestation() throws RecordNotFoundException {
	        return servicestationservice.deleteAllServicestation();
	    }
   @GetMapping("/page")
	public ResponseEntity<Map<String, Object>> getAllEmployeesInPage(
  		 @RequestParam(name = "pageNo", defaultValue = "0") int pageNo,
  		 @RequestParam(name = "pageSize", defaultValue = "2") int pageSize,
  		 @RequestParam(name = "sortBy", defaultValue = "id") String sortBy) {
  	 return servicestationservice.getAllServiceStationsInPage(pageNo, pageSize, sortBy);
   }

  
//   @PostMapping("/getsearch")
//  	public ResponseEntity<List<Servicestation>> getAllByget(@RequestBody Servicestation servicestation) {
//     	 return servicestationservice.getAllByget(servicestation);
//      }
   
//   @GetMapping("/min")
//   public ResponseEntity<List<Servicestation>> getMin() {
//  	 return servicestationservice.getMin();
//   }
   @PutMapping("/Servicestation/{id}")
   public ResponseEntity<Servicestation> updateServicestation(@PathVariable Long id, @RequestBody Servicestation servicestation) {
       return servicestationservice.updateServicestation(id, servicestation);
   }
   @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
   public ResponseEntity <Servicestation> uploadFile(@RequestParam MultipartFile file) {
       logger.info(String.format("File name '%s' uploaded successfully.", file.getOriginalFilename()));
       return ResponseEntity.ok().build();
   }




      }



