package com.piston.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import com.piston.exception.RecordNotFoundException;
import com.piston.model.Quickrepair;
import com.piston.repository.QuickrepairRepository;
import com.piston.repository.ServicestationCustom;

@Service
public class Quickrepairservice {
	
@Autowired
QuickrepairRepository quickrepairRepository;
@Autowired
private ServicestationCustom servicestationCustom;

public ResponseEntity<Quickrepair> createquickrepair(@Valid Quickrepair quickrepair) {
	try {
		quickrepair.setDate(new Date());
		Quickrepair quickrepairs =quickrepairRepository.save(quickrepair);
		return new ResponseEntity<>(quickrepairs,HttpStatus.CREATED);
	} catch (Exception e) {
		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}

	
}

public ResponseEntity<Quickrepair> findByUserId(String userid) throws RecordNotFoundException {
	Optional<Quickrepair> Quickrepairs = quickrepairRepository.findQuickRepairByuserid(userid);
	
	if (Quickrepairs.isPresent()) {
		return new ResponseEntity<>(Quickrepairs.get(), HttpStatus.OK);
	} else {
		throw new RecordNotFoundException( userid+"didn't work");
	}
}

public ResponseEntity<Quickrepair> findByServiceProviderId(String serviceproviderid) throws RecordNotFoundException {
Optional<Quickrepair> Quickrepairs = quickrepairRepository.findByserviceproviderid(serviceproviderid);
	
	if (Quickrepairs.isPresent()) {
		return new ResponseEntity<>(Quickrepairs.get(), HttpStatus.OK);
	} else {
		throw new RecordNotFoundException(serviceproviderid+"didn't work");
	}
}

public ResponseEntity<List<Quickrepair>> getAllHistory() {
	List<Quickrepair>quickrepairs= new ArrayList<Quickrepair>();
	quickrepairRepository.findAll().forEach(quickrepairs::add);;

    if (quickrepairs.isEmpty()) {
      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    return new ResponseEntity<>(quickrepairs, HttpStatus.OK);
}

public ResponseEntity<Map<String, Object>> getAllQuickrepairInPage(int pageNo, int pageSize, String sortBy) {
	try {
  		 Map<String, Object> response = new HashMap<>();
  	 	Sort sort = Sort.by(sortBy);
  		 Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
  	 	Page<Quickrepair> page = quickrepairRepository.findAll(pageable);
  	 	response.put("data", page.getContent());
  	 	response.put("Total no of pages", page.getTotalPages());
  	 	response.put("Total no of elements", page.getTotalElements());
  	 	response.put("Current page no", page.getNumber());
  		 
  	 	return new ResponseEntity<>(response, HttpStatus.OK);
  	 } catch (Exception e) {
  	 	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
  	 }
}


		public ResponseEntity<List<Quickrepair>> getQuickrepairByFilter(String[] serviceType, String[] vehicleTypes,
				Double latitude, Double longitude, String opentime, String finishtime) {
			Double workDistance = servicestationCustom.getMinWorkId();
			 try {
			   	 	List<Quickrepair> quickrepairs= quickrepairRepository.findByBetterCompany(serviceType,vehicleTypes,latitude,longitude,opentime,finishtime,workDistance);
			   	 
			   	 	if (quickrepairs.isEmpty()) {
			   	   	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			   	 	}
			   	 
			   	 	return new ResponseEntity<>(quickrepairs, HttpStatus.OK);
			   	 } catch (Exception e) {
			   	 	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
			   	 }
}

		public ResponseEntity<HttpStatus> deleteAllHistory() {
			try {
				List<Quickrepair> repair=quickrepairRepository.findAll();
				
				if (repair.isEmpty()) {
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				} else {
					quickrepairRepository.deleteAll(repair);
				}
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			} catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
			}

		public ResponseEntity<HttpStatus> deleteHistoryById(Long id) {
			try {
				Optional<Quickrepair> repair=quickrepairRepository.findById(id);
				
				if (repair.isPresent()) {
					quickrepairRepository.delete(repair.get());
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}
				
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
				
			} catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}

		

}





