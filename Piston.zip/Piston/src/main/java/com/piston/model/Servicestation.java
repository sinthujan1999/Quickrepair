package com.piston.model;

import java.util.Arrays;


import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection="Servicestation")
public class Servicestation {

		
@Id
private Long id;

    private boolean status;
	
	@NotBlank(message = "CompanyName must not be empty")
	private String companyName;
 
	@NotEmpty(message = "Address must not be empty")
	private String address;
    
	@NotEmpty(message = "Description must not be empty")
	private String description;
	
	@NotNull(message = "Workdistance must not be empty")
	@Positive(message = "Workdistance must not be negative")
	private Double workDistance;
    
	@NotEmpty(message = "Finishtime must not be empty")
	private String finishtime;
    
	@NotNull(message = "phoneNumber must not be empty")
	private Integer phoneNumber;
   
	
	@NotEmpty(message = "Opentime must not be empty")
	private String opentime;
	
	 @Email(message = "Email should be a valid email")
	@NotEmpty(message = "Email_Address must not be empty")
	private String emailAddress;

	
	private String[] serviceType;
	

	private String[] vehicleTypes;
	
	@NotNull(message="Latitude must not be empty")
	private Double latitude;
	
	@NotNull(message="Longtitude must not be empty")
	private Double longtitude;


	
	



	public Servicestation(Long id, boolean status,
			@NotBlank(message = "CompanyName must not be empty") String companyName,
			@NotEmpty(message = "Address must not be empty") String address,
			@NotEmpty(message = "Description must not be empty") String description,
			@NotNull(message = "Workdistance must not be empty") @Positive(message = "Workdistance must not be negative") Double workDistance,
			@NotEmpty(message = "Finishtime must not be empty") String finishtime,
			@NotNull(message = "phoneNumber must not be empty") Integer phoneNumber,
			@NotEmpty(message = "Opentime must not be empty") String opentime,
			@Email(message = "Email should be a valid email") @NotEmpty(message = "Email_Address must not be empty") String emailAddress,
			String[] serviceType,
			 String[] vehicleTypes,
			@NotNull(message = "Latitude must not be empty") Double latitude,
			@NotNull(message = "Longtitude must not be empty") Double longtitude) {
		super();
		this.id = id;
		this.status = status;
		this.companyName = companyName;
		this.address = address;
		this.description = description;
		this.workDistance = workDistance;
		this.finishtime = finishtime;
		this.phoneNumber = phoneNumber;
		this.opentime = opentime;
		this.emailAddress = emailAddress;
		this.serviceType = serviceType;
		this.vehicleTypes = vehicleTypes;
		this.latitude = latitude;
		this.longtitude = longtitude;
	}







	public Long getId() {
		return id;
	}







	public void setId(Long id) {
		this.id = id;
	}







	public boolean isStatus() {
		return status;
	}







	public void setStatus(boolean status) {
		this.status = status;
	}







	public String getCompanyName() {
		return companyName;
	}







	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}







	public String getAddress() {
		return address;
	}







	public void setAddress(String address) {
		this.address = address;
	}







	public String getDescription() {
		return description;
	}







	public void setDescription(String description) {
		this.description = description;
	}







	public Double getWorkDistance() {
		return workDistance;
	}







	public void setWorkDistance(Double workDistance) {
		this.workDistance = workDistance;
	}







	public String getFinishtime() {
		return finishtime;
	}







	public void setFinishtime(String finishtime) {
		this.finishtime = finishtime;
	}







	public Integer getPhoneNumber() {
		return phoneNumber;
	}







	public void setPhoneNumber(Integer phoneNumber) {
		this.phoneNumber = phoneNumber;
	}







	public String getOpentime() {
		return opentime;
	}







	public void setOpentime(String opentime) {
		this.opentime = opentime;
	}







	public String getEmailAddress() {
		return emailAddress;
	}







	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}







	public String[] getServiceType() {
		return serviceType;
	}







	public void setServiceType(String[] serviceType) {
		this.serviceType = serviceType;
	}







	public String[] getVehicleTypes() {
		return vehicleTypes;
	}







	public void setVehicleTypes(String[] vehicleTypes) {
		this.vehicleTypes = vehicleTypes;
	}







	public Double getLatitude() {
		return latitude;
	}







	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}







	public Double getLongtitude() {
		return longtitude;
	}







	public void setLongtitude(Double longtitude) {
		this.longtitude = longtitude;
	}







	@Override
	public String toString() {
		return "Servicestation [id=" + id + ", status=" + status + ", companyName=" + companyName + ", address="
				+ address + ", description=" + description + ", workDistance=" + workDistance + ", finishtime="
				+ finishtime + ", phoneNumber=" + phoneNumber + ", opentime=" + opentime + ", emailAddress="
				+ emailAddress + ", serviceType=" + Arrays.toString(serviceType) + ", vehicleTypes="
				+ Arrays.toString(vehicleTypes) + ", latitude=" + latitude + ", longtitude=" + longtitude + "]";
	}





	

}
