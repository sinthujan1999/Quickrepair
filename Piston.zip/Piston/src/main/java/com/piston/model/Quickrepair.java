package com.piston.model;

import java.util.Arrays;
import java.util.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Quickrepair")
public class Quickrepair {

	@Id
	private Long id;
	private String userid;
	private String serviceproviderid;
	private Date date;
	private Double price;
	private String serviceStationName;
	private String status;

	
	@NotEmpty(message = "Finishtime must not be empty")
	private String finishtime;
	
	@NotEmpty(message = "vehicleTypes must not be empty")
	private String[] vehicleTypes;
	
	@NotEmpty(message = "Opentime must not be empty")
	private String opentime;
	
	@NotNull(message="Latitude must not be empty")
	private Double latitude;
	
	@NotNull(message="Longtitude must not be empty")
	private Double longtitude;
	
	@NotEmpty(message = "phoneNumber must not be empty")
	private Integer phoneNumber;
	
	@NotEmpty(message = "vehicleTypes must not be empty")
	private String[] serviceType;

	@NotNull(message = "Workdistance must not be empty")
	@Positive(message = "Workdistance must not be negative")
	private Double workDistance;

	public Quickrepair(Long id, String userid, String serviceproviderid, Date date, Double price,
			String serviceStationName, String status,
			@NotEmpty(message = "Finishtime must not be empty") String finishtime,
			@NotEmpty(message = "vehicleTypes must not be empty") String[] vehicleTypes,
			@NotEmpty(message = "Opentime must not be empty") String opentime,
			@NotNull(message = "Latitude must not be empty") Double latitude,
			@NotNull(message = "Longtitude must not be empty") Double longtitude,
			@NotEmpty(message = "phoneNumber must not be empty") Integer phoneNumber,
			@NotEmpty(message = "vehicleTypes must not be empty") String[] serviceType,
			@NotNull(message = "Workdistance must not be empty") @Positive(message = "Workdistance must not be negative") Double workDistance) {
		super();
		this.id = id;
		this.userid = userid;
		this.serviceproviderid = serviceproviderid;
		this.date = date;
		this.price = price;
		this.serviceStationName = serviceStationName;
		this.status = status;
		this.finishtime = finishtime;
		this.vehicleTypes = vehicleTypes;
		this.opentime = opentime;
		this.latitude = latitude;
		this.longtitude = longtitude;
		this.phoneNumber = phoneNumber;
		this.serviceType = serviceType;
		this.workDistance = workDistance;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getServiceproviderid() {
		return serviceproviderid;
	}

	public void setServiceproviderid(String serviceproviderid) {
		this.serviceproviderid = serviceproviderid;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getServiceStationName() {
		return serviceStationName;
	}

	public void setServiceStationName(String serviceStationName) {
		this.serviceStationName = serviceStationName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFinishtime() {
		return finishtime;
	}

	public void setFinishtime(String finishtime) {
		this.finishtime = finishtime;
	}

	public String[] getVehicleTypes() {
		return vehicleTypes;
	}

	public void setVehicleTypes(String[] vehicleTypes) {
		this.vehicleTypes = vehicleTypes;
	}

	public String getOpentime() {
		return opentime;
	}

	public void setOpentime(String opentime) {
		this.opentime = opentime;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongtitude() {
		return longtitude;
	}

	public void setLongtitude(Double longtitude) {
		this.longtitude = longtitude;
	}

	public Integer getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Integer phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String[] getServiceType() {
		return serviceType;
	}

	public void setServiceType(String[] serviceType) {
		this.serviceType = serviceType;
	}

	public Double getWorkDistance() {
		return workDistance;
	}

	public void setWorkDistance(Double workDistance) {
		this.workDistance = workDistance;
	}

	@Override
	public String toString() {
		return "Quickrepair [id=" + id + ", userid=" + userid + ", serviceproviderid=" + serviceproviderid + ", date="
				+ date + ", price=" + price + ", serviceStationName=" + serviceStationName + ", status=" + status
				+ ", finishtime=" + finishtime + ", vehicleTypes=" + Arrays.toString(vehicleTypes) + ", opentime="
				+ opentime + ", latitude=" + latitude + ", longtitude=" + longtitude + ", phoneNumber=" + phoneNumber
				+ ", serviceType=" + Arrays.toString(serviceType) + ", workDistance=" + workDistance + "]";
	}

	
}
