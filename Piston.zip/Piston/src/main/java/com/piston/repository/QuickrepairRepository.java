package com.piston.repository;


import java.util.List;
import java.util.Optional;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import org.springframework.stereotype.Repository;

import com.piston.model.Quickrepair;

@Repository
public interface QuickrepairRepository extends MongoRepository<Quickrepair,Long> {

	Optional<Quickrepair> findQuickRepairByuserid(String userid);


	@Query("{'$and':[{'serviceType':?0,'vehicleTypes':?1,'latitude':?2,'longitude':?3,'opentime':?4 , 'finishtime' : ?5,'workdistance':?6}]}")
	List<Quickrepair> findByBetterCompany(String[] serviceType, String[] vehicleTypes, Double latitude,
			Double longitude, String opentime, String finishtime,Double workDistance);
	
	


	Optional<Quickrepair> findByserviceproviderid(String serviceproviderid);


	
	
}
