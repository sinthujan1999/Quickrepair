package com.piston.repository;

public interface ServicestationCustom {
	public Double getMinWorkId();
}
