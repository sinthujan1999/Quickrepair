package com.piston.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort.Order;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.piston.model.Servicestation;


@Repository
public interface ServicestationRepository extends MongoRepository<Servicestation,Long>{

Optional<Servicestation>findById(Long id);

Optional<Servicestation> findByServiceType(String[] serviceType) ;
	
Optional<Servicestation> findByVehicleTypes(String[] vehicleTypes) ;

Optional<Servicestation> findByCompanyName(String companyName);

@Query("{'opentime' : ?0 , 'finishtime' : ?1}")
List<Servicestation> findServicestationsByOpentimeAndFinishtime(String opentime, String finishtime);

List<Servicestation> findByWorkDistance(Double workDistance);

List<Servicestation> findByCompanyNameContaining(String companyName);


	
	
	}


